# 20je0522_portfolio
Personal Website of Lolla Bharath Kumar(Myself : ) )
This webpage is reactive also looks in vintage style which most of the people would like
i made this using html,bootstrap and mused jquery & DOM for extra look.
